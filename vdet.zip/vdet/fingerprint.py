"""
fingerprint.py - OS and service version fingerprinting from banners,
HTTP headers, and TTL hints.

This does NOT reimplement nmap's full TCP/IP stack fingerprinting
(-O). Instead it uses cheap, reliable signals:
    - Service banners (SSH, FTP, SMTP, etc.)
    - HTTP Server header
    - TTL from a system ping (rough OS family hint)
    - Open port patterns (e.g. 445+3389 open => likely Windows)

Each signal contributes a guess with a confidence level; the highest
confidence guess wins.
"""

import re
import subprocess
import platform

from . import smb_fingerprint


# --- Regexes for common banner formats -> (os_name, version) ---------------

BANNER_OS_PATTERNS = [
    (re.compile(r"OpenSSH_([\d.]+)p?\d*\s+(?:Debian|Ubuntu)", re.I), "Debian/Ubuntu Linux", None),
    (re.compile(r"OpenSSH_([\d.]+).*CentOS", re.I), "CentOS Linux", None),
    (re.compile(r"OpenSSH_([\d.]+)"), None, "OpenSSH {0}"),
    (re.compile(r"Microsoft-IIS/([\d.]+)"), None, "IIS {0}"),
    (re.compile(r"Apache/([\d.]+).*\(Win32\)|\(Win64\)", re.I), "Windows (Apache host)", None),
    (re.compile(r"Apache/([\d.]+)"), None, "Apache {0}"),
    (re.compile(r"nginx/([\d.]+)"), None, "nginx {0}"),
    (re.compile(r"Microsoft FTP Service"), "Windows Server", None),
    (re.compile(r"vsFTPd ([\d.]+)"), None, "vsftpd {0}"),
    (re.compile(r"ProFTPD ([\d.]+)"), None, "ProFTPD {0}"),
]

# IIS version -> likely Windows release(s). Microsoft reuses the same IIS
# major.minor across multiple OS releases, so some entries are genuinely
# ambiguous from the HTTP banner alone (a list, not a single string) and
# are only ever reported at "medium" confidence. Unambiguous entries
# (a single-item list) are reported at "high" confidence.
IIS_TO_WINDOWS = {
    "6.0": ["Windows Server 2003"],
    "7.0": ["Windows Server 2008", "Windows Vista"],
    "7.5": ["Windows Server 2008 R2", "Windows 7"],
    "8.0": ["Windows Server 2012", "Windows 8"],
    "8.5": ["Windows Server 2012 R2", "Windows 8.1"],
    # IIS 10.0 is shared by Windows 10, Server 2016, 2019, and 2022 -
    # cannot be disambiguated from the HTTP banner alone. SMB fingerprinting
    # (see smb_fingerprint.py) is required for an exact match here.
    "10.0": ["Windows 10", "Windows 11", "Windows Server 2016",
              "Windows Server 2019", "Windows Server 2022"],
}

WINDOWS_PORT_SIGNATURE = {135, 139, 445, 3389}


def _ttl_guess(ip, timeout=2):
    """Ping the host once and read the TTL to guess OS family."""
    try:
        system = platform.system().lower()
        if system == "windows":
            cmd = ["ping", "-n", "1", "-w", str(int(timeout * 1000)), ip]
        else:
            cmd = ["ping", "-c", "1", "-W", str(int(timeout)), ip]
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 2)
        text = out.stdout
        m = re.search(r"ttl[=|:]\s*(\d+)", text, re.I)
        if not m:
            return None
        ttl = int(m.group(1))
        # Rough, well-known default TTL bands
        if ttl <= 64:
            return ("Linux/Unix family", "low", ttl)
        elif ttl <= 128:
            return ("Windows family", "low", ttl)
        else:
            return ("Network device (router/switch)", "low", ttl)
    except Exception:
        return None


def _banner_guess(banners):
    """Inspect grabbed banners for known OS/software signatures."""
    guesses = []
    for entry in banners:
        text = entry.get("banner", "") or ""
        if not text:
            continue
        for pattern, os_name, sw_fmt in BANNER_OS_PATTERNS:
            m = pattern.search(text)
            if not m:
                continue
            if os_name:
                guesses.append({"os": os_name, "confidence": "medium", "source": f"banner:{entry['port']}", "raw": text[:120]})
            if sw_fmt:
                version = m.group(1) if m.groups() else ""
                sw = sw_fmt.format(version)
                guesses.append({"software": sw, "confidence": "high", "source": f"banner:{entry['port']}", "raw": text[:120]})
                if "IIS" in sw and version in IIS_TO_WINDOWS:
                    candidates = IIS_TO_WINDOWS[version]
                    is_ambiguous = len(candidates) > 1
                    os_label = candidates[0] if not is_ambiguous else " / ".join(candidates)
                    guesses.append({
                        "os": os_label,
                        "confidence": "medium" if is_ambiguous else "high",
                        "source": f"banner:{entry['port']} (IIS {version} version map"
                                   + (", ambiguous - needs SMB confirmation)" if is_ambiguous else ")"),
                        "raw": text[:120],
                        "ambiguous_candidates": candidates if is_ambiguous else None,
                    })
    return guesses


def _port_pattern_guess(open_ports):
    open_set = set(open_ports)
    if WINDOWS_PORT_SIGNATURE & open_set:
        matched = sorted(WINDOWS_PORT_SIGNATURE & open_set)
        return {"os": "Windows (unspecified version)", "confidence": "low",
                "source": f"open ports {matched}"}
    return None


def fingerprint_host(ip, open_ports, banners, use_ttl=True, use_smb=True):
    """
    Combine all available signals into a best-guess OS/service fingerprint.
    Returns:
        {
          "os_guesses": [...],
          "software_guesses": [...],
          "best_os": str or None,
          "best_os_confidence": str or None,
        }

    Signal priority: SMB2 NTLMSSP build number (exact, "certain") is
    authoritative when available - it's the only signal that can tell
    Windows 10 apart from Server 2016/2019/2022, since they share IIS 10.0.
    Falls back to banner/TTL/port-pattern heuristics when SMB isn't open
    or the exchange fails (SMB signing-only hosts, non-Windows targets,
    firewalled 445, etc.).
    """
    all_guesses = []

    # SMB2-based exact fingerprint - highest priority signal, Windows-only.
    # Prefer port 445 (modern SMB-direct); fall back to legacy NetBIOS on
    # 139 since some lab/hardened configs expose only one of the two.
    if use_smb:
        smb_result = None
        if 445 in open_ports:
            smb_result = smb_fingerprint.fingerprint_via_smb(ip, port=445)
        if not smb_result and 139 in open_ports:
            smb_result = smb_fingerprint.fingerprint_via_smb(ip, port=139)
        if smb_result:
            all_guesses.append({
                "os": smb_result["os_name"],
                "confidence": "certain",
                "source": f"smb2_ntlmssp (build {smb_result['build']})",
                "build": smb_result["build"],
            })

    all_guesses.extend(_banner_guess(banners))

    port_guess = _port_pattern_guess(open_ports)
    if port_guess:
        all_guesses.append(port_guess)

    if use_ttl:
        ttl_result = _ttl_guess(ip)
        if ttl_result:
            os_name, confidence, ttl_val = ttl_result
            all_guesses.append({"os": os_name, "confidence": confidence, "source": f"ttl={ttl_val}"})

    os_guesses = [g for g in all_guesses if "os" in g]
    software_guesses = [g for g in all_guesses if "software" in g]

    confidence_rank = {"certain": 4, "high": 3, "medium": 2, "low": 1}
    best_os = None
    best_conf = None
    if os_guesses:
        best = max(os_guesses, key=lambda g: confidence_rank.get(g["confidence"], 0))
        best_os = best["os"]
        best_conf = best["confidence"]

    return {
        "os_guesses": os_guesses,
        "software_guesses": software_guesses,
        "best_os": best_os,
        "best_os_confidence": best_conf,
    }
