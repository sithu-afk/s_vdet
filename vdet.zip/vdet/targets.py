"""
targets.py - Parses target specifications into a flat list of IP addresses.

Supports:
    192.168.1.10            single IP
    192.168.1.0/24          CIDR notation
    192.168.1.10-50         short IP range (last octet)
    192.168.1.10-192.168.1.50   full IP range
    example.com              hostname (resolved via DNS)
    -iL targets.txt          file with one target per line (any of the above)
"""

import ipaddress
import socket


class TargetParseError(Exception):
    pass


def resolve_hostname(hostname):
    """Resolve a hostname to an IP address. Raises TargetParseError on failure."""
    try:
        return socket.gethostbyname(hostname)
    except socket.gaierror as e:
        raise TargetParseError(f"Could not resolve hostname '{hostname}': {e}")


def _is_ip(s):
    try:
        ipaddress.ip_address(s)
        return True
    except ValueError:
        return False


def _parse_short_range(spec):
    """Parse '192.168.1.10-50' -> list of IPs from .10 to .50"""
    base, end = spec.split("-", 1)
    parts = base.strip().split(".")
    if len(parts) != 4:
        raise TargetParseError(f"Invalid short range base: {base}")
    prefix = ".".join(parts[:3])
    start_octet = int(parts[3])
    end_octet = int(end.strip())
    if not (0 <= start_octet <= 255 and 0 <= end_octet <= 255):
        raise TargetParseError(f"Octet out of range in: {spec}")
    if end_octet < start_octet:
        raise TargetParseError(f"Invalid range (end < start): {spec}")
    return [f"{prefix}.{i}" for i in range(start_octet, end_octet + 1)]


def _parse_full_range(spec):
    """Parse '192.168.1.10-192.168.1.50' -> list of IPs in that inclusive range"""
    start_s, end_s = spec.split("-", 1)
    start_ip = ipaddress.ip_address(start_s.strip())
    end_ip = ipaddress.ip_address(end_s.strip())
    if int(end_ip) < int(start_ip):
        raise TargetParseError(f"Invalid range (end < start): {spec}")
    return [str(ipaddress.ip_address(i)) for i in range(int(start_ip), int(end_ip) + 1)]


def parse_target_spec(spec):
    """
    Parse a single target spec string into a list of IP address strings.
    Does not resolve hostnames unless nothing else matches.
    """
    spec = spec.strip()
    if not spec:
        return []

    # CIDR
    if "/" in spec:
        try:
            net = ipaddress.ip_network(spec, strict=False)
            return [str(ip) for ip in net.hosts()] or [str(net.network_address)]
        except ValueError as e:
            raise TargetParseError(f"Invalid CIDR '{spec}': {e}")

    # Range
    if "-" in spec:
        # Distinguish short range (192.168.1.10-50) vs full range (a-b both full IPs)
        after_dash = spec.split("-", 1)[1].strip()
        if _is_ip(after_dash):
            return _parse_full_range(spec)
        else:
            return _parse_short_range(spec)

    # Plain IP
    if _is_ip(spec):
        return [spec]

    # Hostname
    resolved = resolve_hostname(spec)
    return [resolved]


def load_targets_from_file(path):
    """Read a target list file, one spec per line, '#' for comments."""
    specs = []
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            specs.append(line)
    return specs


def resolve_targets(target_specs):
    """
    Given a list of raw target spec strings, return a de-duplicated,
    order-preserved list of IP address strings.
    """
    all_ips = []
    seen = set()
    for spec in target_specs:
        for ip in parse_target_spec(spec):
            if ip not in seen:
                seen.add(ip)
                all_ips.append(ip)
    return all_ips
