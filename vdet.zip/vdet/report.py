"""
report.py - Formats scan results for terminal display or file export
(JSON / plain text).
"""

import json
import datetime

SEVERITY_COLOR = {
    "critical": "\033[95m",  # magenta
    "high": "\033[91m",      # red
    "medium": "\033[93m",    # yellow
    "low": "\033[94m",       # blue
    "info": "\033[90m",      # gray
}
RESET = "\033[0m"
BOLD = "\033[1m"

SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def _color(sev, text):
    c = SEVERITY_COLOR.get(sev.lower(), "")
    return f"{c}{text}{RESET}" if c else text


def build_host_result(ip, open_ports, banners, fingerprint, misconfig_findings, cve_matches):
    return {
        "host": ip,
        "scan_time": datetime.datetime.utcnow().isoformat() + "Z",
        "open_ports": open_ports,
        "services": banners,
        "os_fingerprint": {
            "best_guess": fingerprint.get("best_os"),
            "confidence": fingerprint.get("best_os_confidence"),
            "all_os_guesses": fingerprint.get("os_guesses", []),
            "software_guesses": fingerprint.get("software_guesses", []),
        },
        "misconfig_findings": misconfig_findings,
        "cve_matches": cve_matches,
        "summary": {
            "open_port_count": len(open_ports),
            "misconfig_count": len(misconfig_findings),
            "cve_count": len(cve_matches),
            "critical_cve_count": sum(1 for c in cve_matches if (c.get("cvss") or 0) >= 9.0),
        },
    }


def print_host_report(result, min_severity="info", use_color=True):
    ip = result["host"]
    print(f"\n{BOLD}=== Scan results for {ip} ==={RESET}")

    open_ports = result["open_ports"]
    if not open_ports:
        print("  No open ports found.")
        return

    print(f"\n  Open ports ({len(open_ports)}):")
    for svc in result["services"]:
        port = svc["port"]
        guess = svc.get("service_guess", "unknown")
        banner_line = (svc.get("banner") or "").splitlines()[0] if svc.get("banner") else ""
        banner_line = banner_line[:80]
        print(f"    {port:<6} {guess:<15} {banner_line}")

    fp = result["os_fingerprint"]
    if fp.get("best_guess"):
        print(f"\n  OS fingerprint: {BOLD}{fp['best_guess']}{RESET} (confidence: {fp['confidence']})")
    if fp.get("software_guesses"):
        print("  Software detected:")
        for sw in fp["software_guesses"]:
            print(f"    - {sw['software']} (source: {sw['source']})")

    findings = result["misconfig_findings"]
    min_rank = SEVERITY_ORDER.get(min_severity, 0)
    shown_findings = [f for f in findings if SEVERITY_ORDER.get(f["severity"], 0) >= min_rank]
    if shown_findings:
        print(f"\n  Misconfiguration findings ({len(shown_findings)}):")
        for f in shown_findings:
            sev = f["severity"].upper()
            label = _color(f["severity"], f"[{sev}]") if use_color else f"[{sev}]"
            port_str = f" (port {f['port']})" if f.get("port") else ""
            print(f"    {label} {f['title']}{port_str}")
            print(f"           {f['description']}")

    cves = result["cve_matches"]
    shown_cves = [c for c in cves if (c.get("severity", "").lower() in SEVERITY_ORDER
                                        and SEVERITY_ORDER.get(c["severity"].lower(), 0) >= min_rank)
                  or min_severity == "info"]
    if shown_cves:
        print(f"\n  CVE matches ({len(shown_cves)}):")
        for c in shown_cves:
            sev = (c.get("severity") or "UNKNOWN").upper()
            cvss = c.get("cvss")
            cvss_str = f"CVSS {cvss}" if cvss is not None else "CVSS N/A"
            label = _color(sev.lower(), f"[{sev}]") if use_color else f"[{sev}]"
            print(f"    {label} {c['id']} ({cvss_str}) [{c.get('source', 'unknown')}]")
            print(f"           {c.get('summary', '')}")

    s = result["summary"]
    print(f"\n  {BOLD}Summary:{RESET} {s['open_port_count']} open ports, "
          f"{s['misconfig_count']} misconfig findings, "
          f"{s['cve_count']} CVE matches ({s['critical_cve_count']} critical/CVSS>=9.0)")


def write_json_report(results, path):
    with open(path, "w") as f:
        json.dump({"scan_results": results, "generated": datetime.datetime.utcnow().isoformat() + "Z"},
                   f, indent=2)


def write_text_report(results, path, min_severity="info"):
    import io
    import contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        for r in results:
            print_host_report(r, min_severity=min_severity, use_color=False)
    with open(path, "w") as f:
        f.write(buf.getvalue())


def compute_exit_code(results):
    """
    Exit code convention (useful for CI/CD gating):
        0 - no findings above 'low'
        1 - medium findings present
        2 - high findings present
        3 - critical findings present
    """
    max_level = 0
    for r in results:
        for f in r["misconfig_findings"]:
            max_level = max(max_level, SEVERITY_ORDER.get(f["severity"], 0))
        for c in r["cve_matches"]:
            cvss = c.get("cvss") or 0
            if cvss >= 9.0:
                max_level = max(max_level, SEVERITY_ORDER["critical"])
            elif cvss >= 7.0:
                max_level = max(max_level, SEVERITY_ORDER["high"])
            elif cvss >= 4.0:
                max_level = max(max_level, SEVERITY_ORDER["medium"])
    return max(0, max_level - 1) if max_level >= 2 else 0
