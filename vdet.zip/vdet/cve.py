"""
cve.py - CVE matching engine.

Three tiers of lookup, used in this priority order:
    1. Local SQLite cache (built via `vdet --update-cve-db`, fastest,
       works fully offline, no rate limits)
    2. Live NVD REST API (requires network + optionally an API key
       for higher rate limits)
    3. Built-in seed DB (data/cve_seed.py) - small curated set of
       well-known high-impact CVEs, always available as a last resort
       so results are never empty for common lab/CTF targets.
"""

import json
import os
import sqlite3
import time
import urllib.request
import urllib.parse
import urllib.error

from .data.cve_seed import lookup_seed_cves

NVD_API_BASE = "https://services.nvd.nist.gov/rest/json/cves/2.0"
DEFAULT_DB_PATH = os.path.expanduser("~/.s_vdet/cve_cache.sqlite3")


# --- Local SQLite cache ------------------------------------------------------

def init_db(db_path=DEFAULT_DB_PATH):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cves (
            cve_id TEXT PRIMARY KEY,
            cpe_match TEXT,
            cvss REAL,
            severity TEXT,
            summary TEXT,
            published TEXT
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cpe ON cves(cpe_match)")
    conn.commit()
    return conn


def db_has_data(db_path=DEFAULT_DB_PATH):
    if not os.path.exists(db_path):
        return False
    try:
        conn = sqlite3.connect(db_path)
        count = conn.execute("SELECT COUNT(*) FROM cves").fetchone()[0]
        conn.close()
        return count > 0
    except sqlite3.OperationalError:
        return False


def query_local_db(cpe_substring, db_path=DEFAULT_DB_PATH, limit=25):
    """Query the local cache for CVEs whose cpe_match contains cpe_substring."""
    if not db_has_data(db_path):
        return []
    conn = sqlite3.connect(db_path)
    rows = conn.execute(
        "SELECT cve_id, cvss, severity, summary FROM cves "
        "WHERE cpe_match LIKE ? LIMIT ?",
        (f"%{cpe_substring}%", limit),
    ).fetchall()
    conn.close()
    return [
        {"id": r[0], "cvss": r[1], "severity": r[2], "summary": r[3], "source": "local_db"}
        for r in rows
    ]


def update_local_db(cpe_names, api_key=None, db_path=DEFAULT_DB_PATH, delay=6.0):
    """
    Pull CVE records for each given CPE name from the NVD API and store
    them in the local SQLite cache. Respects NVD's public rate limit
    (~5 req/30s without a key => we default to a conservative delay).
    Returns the number of CVE records inserted.
    """
    conn = init_db(db_path)
    inserted = 0
    for cpe in cpe_names:
        records = query_nvd_api(cpe_name=cpe, api_key=api_key)
        for rec in records:
            conn.execute(
                "INSERT OR REPLACE INTO cves (cve_id, cpe_match, cvss, severity, summary, published) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (rec["id"], cpe, rec.get("cvss"), rec.get("severity"),
                 rec.get("summary"), rec.get("published", "")),
            )
            inserted += 1
        conn.commit()
        time.sleep(delay)
    conn.close()
    return inserted


# --- Live NVD API -------------------------------------------------------------

def query_nvd_api(cpe_name=None, keyword=None, api_key=None, timeout=10):
    """
    Query the live NVD REST API. Returns a list of normalized CVE dicts.
    Fails silently (returns []) on network errors so callers can fall
    back to the seed DB - this keeps the tool usable when NVD is
    unreachable or the environment has restricted network egress.
    """
    params = {}
    if cpe_name:
        params["cpeName"] = cpe_name
    if keyword:
        params["keywordSearch"] = keyword
    if not params:
        return []

    url = f"{NVD_API_BASE}?{urllib.parse.urlencode(params)}"
    headers = {"User-Agent": "s_vdet/0.1.0"}
    if api_key:
        headers["apiKey"] = api_key

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode())
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, ValueError):
        return []

    results = []
    for vuln in data.get("vulnerabilities", []):
        cve = vuln.get("cve", {})
        cve_id = cve.get("id", "")
        descriptions = cve.get("descriptions", [])
        summary = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")

        cvss = None
        severity = None
        metrics = cve.get("metrics", {})
        for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
            if key in metrics and metrics[key]:
                cvss_data = metrics[key][0].get("cvssData", {})
                cvss = cvss_data.get("baseScore")
                severity = metrics[key][0].get("baseSeverity") or cvss_data.get("baseSeverity")
                break

        results.append({
            "id": cve_id,
            "cvss": cvss,
            "severity": severity or "UNKNOWN",
            "summary": summary[:300],
            "published": cve.get("published", ""),
            "source": "nvd_api",
        })
    return results


# --- Orchestration ------------------------------------------------------------

def match_cves(os_guesses, software_guesses, open_ports=None, source="auto",
                db_path=DEFAULT_DB_PATH, api_key=None, min_cvss=0.0):
    """
    Main entry point: given fingerprint guesses for a host, return the
    combined, de-duplicated list of matched CVEs.

    source: "local" (SQLite cache only), "nvd" (live API only),
            "seed" (offline seed DB only), "auto" (try local -> seed;
            seed is instant so we always include it for coverage).
    """
    match_keys = []
    for g in os_guesses:
        if g.get("os"):
            match_keys.append(g["os"])
    for g in software_guesses:
        if g.get("software"):
            match_keys.append(g["software"])

    all_results = []
    seen_ids = set()

    def _add(records):
        for r in records:
            if r["id"] not in seen_ids:
                seen_ids.add(r["id"])
                all_results.append(r)

    if source in ("local", "auto"):
        for key in match_keys:
            _add(query_local_db(key, db_path=db_path))

    if source == "nvd":
        for key in match_keys:
            _add(query_nvd_api(keyword=key, api_key=api_key))

    if source in ("seed", "auto") or not all_results:
        seed_matches = lookup_seed_cves(match_keys)
        for r in seed_matches:
            r = dict(r)
            r["source"] = r.get("source", "seed_db")
        _add(seed_matches)

    if min_cvss > 0:
        all_results = [r for r in all_results if (r.get("cvss") or 0) >= min_cvss]

    all_results.sort(key=lambda r: r.get("cvss") or 0, reverse=True)
    return all_results
