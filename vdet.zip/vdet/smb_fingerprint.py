"""
smb_fingerprint.py - Precise Windows OS/build fingerprinting via SMB2.

HTTP/IIS-banner fingerprinting cannot distinguish Windows 10 from Server
2016/2019/2022 (they share IIS 10.0). This module gets an authoritative
answer instead by talking raw SMB2 to port 445:

    1. SMB2 NEGOTIATE  - agree on a dialect
    2. SMB2 SESSION_SETUP with an NTLMSSP NEGOTIATE_MESSAGE (wrapped in a
       minimal SPNEGO NegTokenInit)
    3. The server's NTLMSSP CHALLENGE_MESSAGE optionally carries a VERSION
       field: ProductMajorVersion, ProductMinorVersion, ProductBuild -
       the exact Windows build number, no login/credentials required.

This is the same technique used by Impacket, CrackMapExec/nxc, and
nmap's smb-os-discovery.nse. No authentication actually completes -
we stop after reading the challenge.

Reference: MS-SMB2, MS-NLMP (NTLM Authentication Protocol).
"""

import socket
import struct
import uuid

# Windows NT build number -> marketing name. Extend as needed; unknown
# builds fall back to "Windows NT 10.0 (build N)" so it's still useful.
BUILD_TO_NAME = {
    22000: "Windows 11 21H2", 22621: "Windows 11 22H2", 22631: "Windows 11 23H2",
    26100: "Windows 11 24H2",
    19041: "Windows 10 2004", 19042: "Windows 10 20H2", 19043: "Windows 10 21H1",
    19044: "Windows 10 21H2", 19045: "Windows 10 22H2",
    18362: "Windows 10 1903", 18363: "Windows 10 1909",
    17763: "Windows 10 1809 / Windows Server 2019",
    17134: "Windows 10 1803", 16299: "Windows 10 1709", 15063: "Windows 10 1703",
    14393: "Windows 10 1607 / Windows Server 2016",
    10586: "Windows 10 1511", 10240: "Windows 10 1507",
    20348: "Windows Server 2022",
    9600: "Windows 8.1 / Windows Server 2012 R2",
    9200: "Windows 8 / Windows Server 2012",
    7601: "Windows 7 SP1 / Windows Server 2008 R2 SP1",
    7600: "Windows 7 / Windows Server 2008 R2",
    6003: "Windows Server 2008 SP2", 6002: "Windows Vista SP2",
    6001: "Windows Vista SP1 / Windows Server 2008",
    3790: "Windows Server 2003",
}


class SMBFingerprintError(Exception):
    pass


def _encode_netbios_name(name, suffix=0x00):
    """First-level NetBIOS name encoding: 16-byte padded name -> 32 ASCII
    nibble characters, framed with a length byte and null terminator."""
    name = name.upper()[:15]
    padded = (name.ljust(15) + chr(suffix)).encode("ascii")
    encoded = "".join(chr(0x41 + (b >> 4)) + chr(0x41 + (b & 0x0F)) for b in padded)
    return bytes([32]) + encoded.encode("ascii") + b"\x00"


def _build_nbt_session_request(called_name="*SMBSERVER", calling_name="VDET"):
    """NetBIOS Session Service 'Session Request' (used on port 139 only -
    port 445 hosts SMB directly over TCP with no NBT session step)."""
    payload = _encode_netbios_name(called_name) + _encode_netbios_name(calling_name)
    header = b"\x81" + struct.pack(">I", len(payload))[1:]
    return header + payload


def _establish_nbt_session(sock):
    """Send a Session Request and check for a positive (0x82) response.
    Returns True on success, False if the server rejects it (0x83)."""
    sock.sendall(_build_nbt_session_request())
    resp = _recv_exact(sock, 4)
    return resp[0] == 0x82


def _nbss_wrap(payload):
    """Wrap an SMB2 message in a 4-byte NetBIOS Session Service header."""
    return b"\x00" + struct.pack(">I", len(payload))[1:] + payload


def _recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise SMBFingerprintError("connection closed early")
        buf += chunk
    return buf


def _recv_nbss_message(sock):
    header = _recv_exact(sock, 4)
    length = struct.unpack(">I", b"\x00" + header[1:])[0]
    return _recv_exact(sock, length)


def _build_smb2_header(command, message_id, credit_charge=1, process_id=0xFEFF, tree_id=0, session_id=0):
    return struct.pack(
        "<4sHHIHHIIQIIQ16s",
        b"\xfeSMB", 64, credit_charge, 0, command, 1, 0, 0,
        message_id, process_id, tree_id, session_id, b"\x00" * 16,
    )


def _build_negotiate_request(message_id=0):
    header = _build_smb2_header(command=0x0000, message_id=message_id)
    dialects = [0x0202, 0x0210, 0x0300, 0x0302]
    client_guid = uuid.uuid4().bytes
    body = struct.pack(
        "<HHHHI16s8s",
        36, len(dialects), 0x0001, 0, 0, client_guid, b"\x00" * 8,
    )
    body += b"".join(struct.pack("<H", d) for d in dialects)
    return header + body


# --- Minimal hand-rolled NTLMSSP + SPNEGO construction ----------------------
# We don't need a general ASN.1 library: the SPNEGO NegTokenInit we send is
# fixed-shape (one mechType OID + one mechToken), so it's built directly.

NTLMSSP_OID = bytes.fromhex("2a864886f712010202")  # 1.3.6.1.4.1.311.2.2.10


def _asn1_len(n):
    if n < 0x80:
        return bytes([n])
    body = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(body)]) + body


def _asn1_tlv(tag, value):
    return bytes([tag]) + _asn1_len(len(value)) + value


def _build_ntlm_negotiate_message():
    signature = b"NTLMSSP\x00"
    msg_type = struct.pack("<I", 1)
    # Flags: NEGOTIATE_UNICODE | NEGOTIATE_NTLM | NEGOTIATE_ALWAYS_SIGN
    #      | NEGOTIATE_VERSION (0x02000000) - asks the server to include
    #        its OS version in the CHALLENGE response
    flags = 0x00000001 | 0x00000200 | 0x00008000 | 0x02000000
    flags_b = struct.pack("<I", flags)
    domain_fields = struct.pack("<HHI", 0, 0, 0)
    workstation_fields = struct.pack("<HHI", 0, 0, 0)
    return signature + msg_type + flags_b + domain_fields + workstation_fields


def _build_spnego_neg_token_init(ntlm_negotiate):
    mech_types = _asn1_tlv(0x30, _asn1_tlv(0x06, NTLMSSP_OID))
    mech_types_field = _asn1_tlv(0xA0, mech_types)
    mech_token = _asn1_tlv(0xA2, _asn1_tlv(0x04, ntlm_negotiate))
    neg_token_init_inner = _asn1_tlv(0x30, mech_types_field + mech_token)
    neg_token_init = _asn1_tlv(0xA0, neg_token_init_inner)
    spnego_oid = _asn1_tlv(0x06, bytes.fromhex("2b0601050502"))  # 1.3.6.1.5.5.2
    app_body = spnego_oid + neg_token_init
    return _asn1_tlv(0x60, app_body)  # GSS-API InitialContextToken


def _build_session_setup_request(message_id, security_blob):
    header = _build_smb2_header(command=0x0001, message_id=message_id)
    sec_buf_offset = 64 + 24  # header (64) + fixed session setup body (24)
    body = struct.pack(
        "<HBBIIHHQ",
        25, 0, 1, 0, 0, sec_buf_offset, len(security_blob), 0,
    )
    return header + body + security_blob


def _parse_smb2_header(data):
    fields = struct.unpack_from("<4sHHIHHIIQIIQ16s", data, 0)
    return {"command": fields[4], "status": fields[3]}


def _find_ntlm_challenge(blob):
    idx = blob.find(b"NTLMSSP\x00")
    if idx == -1:
        return None
    msg_type = struct.unpack_from("<I", blob, idx + 8)[0]
    if msg_type != 2:
        return None
    # CHALLENGE_MESSAGE layout: Signature(8) MessageType(4) TargetNameFields(8)
    # NegotiateFlags(4) ServerChallenge(8) Reserved(8) TargetInfoFields(8)
    # Version(8, optional - present when NEGOTIATE_VERSION flag was echoed back)
    flags = struct.unpack_from("<I", blob, idx + 20)[0]
    has_version = bool(flags & 0x02000000)
    version_offset = idx + 48
    if not has_version or version_offset + 8 > len(blob):
        return None
    major, minor, build, _reserved, ntlm_rev = struct.unpack_from("<BBH3sB", blob, version_offset)
    return {"major": major, "minor": minor, "build": build, "ntlm_revision": ntlm_rev}


def fingerprint_via_smb(ip, port=445, timeout=4.0):
    """
    Connect to ip:port and attempt SMB2-based OS fingerprinting.
    Returns a dict with keys {major, minor, build, os_name, method} on
    success, or None if SMB isn't available / the exchange fails for any
    reason (SMB signing requirements, SMB1-only host, closed port, etc.)
    Never raises - callers can treat None as "fall back to banner-based
    fingerprinting."

    port=445: modern hosts speak SMB2 directly over TCP.
    port=139: legacy NetBIOS Session Service - requires an extra
              session-establishment handshake before SMB2 negotiate can
              be sent. Some lab/hardened Windows configs expose 139
              without 445 (or vice versa), so callers should try both.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            sock.connect((ip, port))

            if port == 139:
                if not _establish_nbt_session(sock):
                    return None

            neg_req = _build_negotiate_request(message_id=0)
            sock.sendall(_nbss_wrap(neg_req))
            neg_resp = _recv_nbss_message(sock)
            hdr = _parse_smb2_header(neg_resp)
            if hdr["command"] != 0x0000:
                return None

            ntlm_negotiate = _build_ntlm_negotiate_message()
            spnego_blob = _build_spnego_neg_token_init(ntlm_negotiate)
            setup_req = _build_session_setup_request(message_id=1, security_blob=spnego_blob)
            sock.sendall(_nbss_wrap(setup_req))
            setup_resp = _recv_nbss_message(sock)

            version = _find_ntlm_challenge(setup_resp)
            if not version:
                return None

            build = version["build"]
            os_name = BUILD_TO_NAME.get(build)
            if not os_name:
                os_name = f"Windows NT {version['major']}.{version['minor']} (build {build})"

            return {
                "major": version["major"],
                "minor": version["minor"],
                "build": build,
                "os_name": os_name,
                "method": "smb2_ntlmssp_version",
            }

    except (socket.timeout, ConnectionRefusedError, OSError, SMBFingerprintError, struct.error):
        return None
