"""
banner.py - Connects to open ports and grabs service banners for
fingerprinting (service name + version string).
"""

import socket
import ssl

from .data.top_ports import SERVICE_HINTS

HTTP_PROBE = b"HEAD / HTTP/1.0\r\nHost: %b\r\nConnection: close\r\n\r\n"


def _recv_banner(sock, max_bytes=1024):
    try:
        data = sock.recv(max_bytes)
        return data.decode(errors="ignore").strip()
    except (socket.timeout, OSError):
        return ""


def grab_banner(ip, port, timeout=2.0):
    """
    Connect to ip:port and attempt to retrieve a service banner.
    Returns dict: {port, service_guess, banner, tls}
    """
    service_guess = SERVICE_HINTS.get(port, "unknown")
    result = {"port": port, "service_guess": service_guess, "banner": "", "tls": False}

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            sock.connect((ip, port))

            if port in (443, 8443, 993, 995, 465, 636, 5986):
                # TLS-wrapped service - grab cert + attempt banner over TLS
                result["tls"] = True
                try:
                    ctx = ssl.create_default_context()
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                    with ctx.wrap_socket(sock, server_hostname=ip) as tls_sock:
                        tls_sock.settimeout(timeout)
                        cert = tls_sock.getpeercert(binary_form=False)
                        result["tls_version"] = tls_sock.version()
                        if port in (443, 8443):
                            tls_sock.send(HTTP_PROBE % ip.encode())
                            result["banner"] = _recv_banner(tls_sock, 2048).split("\r\n")[0:5]
                            result["banner"] = "\n".join(result["banner"]) if isinstance(result["banner"], list) else result["banner"]
                except ssl.SSLError as e:
                    result["tls_error"] = str(e)
                return result

            if port in (80, 8080, 8000, 8888, 8081):
                sock.send(HTTP_PROBE % ip.encode())
                result["banner"] = _recv_banner(sock, 2048)
                return result

            if port in (21, 22, 23, 25, 110, 143):
                # These services typically send a banner immediately on connect
                result["banner"] = _recv_banner(sock)
                return result

            # Generic: try reading first, if nothing comes send a newline nudge
            banner = _recv_banner(sock, 512)
            if not banner:
                try:
                    sock.send(b"\r\n")
                    banner = _recv_banner(sock, 512)
                except OSError:
                    pass
            result["banner"] = banner
            return result

    except (socket.timeout, ConnectionRefusedError, OSError) as e:
        result["error"] = str(e)
        return result


def grab_banners(ip, open_ports, timeout=2.0):
    """Grab banners for every open port on a host. Returns list of dicts."""
    return [grab_banner(ip, port, timeout=timeout) for port in open_ports]
