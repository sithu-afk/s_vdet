"""
rules.py - Static misconfiguration / known-bad-pattern ruleset.

Each rule inspects open ports + banners for a host and yields Finding
dicts when a pattern matches. This is intentionally simple/explicit
(no plugin system) so it's easy to read, extend, and audit.
"""

import re
import ssl
import socket
import datetime

SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def finding(rule_id, title, severity, description, port=None, evidence=None):
    return {
        "rule_id": rule_id,
        "title": title,
        "severity": severity,
        "description": description,
        "port": port,
        "evidence": evidence,
    }


# --- Individual checks ------------------------------------------------------

def check_telnet_open(ip, open_ports, banners):
    if 23 in open_ports:
        return [finding(
            "TELNET-001", "Telnet service exposed", "high",
            "Telnet transmits credentials and data in plaintext. Any traffic, "
            "including login credentials, can be trivially intercepted. "
            "Disable Telnet and use SSH instead.",
            port=23,
        )]
    return []


def check_ftp_anonymous(ip, open_ports, banners, timeout=3.0):
    if 21 not in open_ports:
        return []
    findings = []
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            sock.connect((ip, 21))
            sock.recv(512)
            sock.send(b"USER anonymous\r\n")
            resp1 = sock.recv(512).decode(errors="ignore")
            sock.send(b"PASS anonymous@\r\n")
            resp2 = sock.recv(512).decode(errors="ignore")
            if resp2.startswith("230"):
                findings.append(finding(
                    "FTP-001", "Anonymous FTP login allowed", "high",
                    "The FTP service accepts anonymous logins, which may expose "
                    "files or allow unauthorized uploads. Disable anonymous access "
                    "unless explicitly required.",
                    port=21, evidence=resp2.strip()[:200],
                ))
    except (socket.timeout, OSError):
        pass
    return findings


def check_unencrypted_services(ip, open_ports, banners):
    findings = []
    unencrypted_map = {
        110: ("POP3", "POP3-001"),
        143: ("IMAP", "IMAP-001"),
        161: ("SNMP", "SNMP-001"),
    }
    for port, (name, rule_id) in unencrypted_map.items():
        if port in open_ports:
            findings.append(finding(
                rule_id, f"Unencrypted {name} service exposed", "medium",
                f"{name} is running without TLS on port {port}. Credentials and "
                f"data sent to this service can be intercepted in transit. "
                f"Prefer the TLS variant of this service.",
                port=port,
            ))
    return findings


def check_smb_exposed(ip, open_ports, banners):
    findings = []
    if 445 in open_ports:
        findings.append(finding(
            "SMB-001", "SMB (445) exposed to network", "medium",
            "SMB file sharing is reachable. If SMBv1 is enabled or signing is "
            "disabled, this host is vulnerable to relay attacks and exploits "
            "such as EternalBlue (CVE-2017-0144). Restrict SMB to trusted "
            "networks and disable SMBv1.",
            port=445,
        ))
    if 139 in open_ports:
        findings.append(finding(
            "SMB-002", "NetBIOS session service exposed", "low",
            "Port 139 (NetBIOS-SSN) is open, often alongside legacy SMB. "
            "Consider restricting this to trusted internal networks only.",
            port=139,
        ))
    return findings


def check_rdp_exposed(ip, open_ports, banners):
    if 3389 in open_ports:
        return [finding(
            "RDP-001", "RDP exposed to network", "high",
            "Remote Desktop Protocol is reachable. Internet-facing RDP is a "
            "top initial-access vector for ransomware operators (brute force, "
            "BlueKeep CVE-2019-0708). Restrict via VPN/firewall and enable "
            "Network Level Authentication.",
            port=3389,
        )]
    return []


def check_database_exposed(ip, open_ports, banners):
    findings = []
    db_ports = {
        3306: ("MySQL", "DB-001"),
        5432: ("PostgreSQL", "DB-002"),
        1433: ("MSSQL", "DB-003"),
        27017: ("MongoDB", "DB-004"),
        6379: ("Redis", "DB-005"),
        9200: ("Elasticsearch", "DB-006"),
    }
    for port, (name, rule_id) in db_ports.items():
        if port in open_ports:
            sev = "critical" if name in ("MongoDB", "Redis", "Elasticsearch") else "high"
            findings.append(finding(
                rule_id, f"{name} database exposed to network", sev,
                f"{name} is directly reachable on port {port}. Databases should "
                f"never be exposed beyond an internal network/VPC. If this was "
                f"unintentional, firewall this port immediately and check for "
                f"unauthorized access in logs.",
                port=port,
            ))
    return findings


def check_vnc_exposed(ip, open_ports, banners):
    if 5900 in open_ports:
        return [finding(
            "VNC-001", "VNC exposed to network", "high",
            "VNC remote desktop is reachable. VNC often uses weak authentication "
            "and unencrypted transport by default. Restrict access and use a "
            "VNC variant with strong auth + encryption, or tunnel over SSH/VPN.",
            port=5900,
        )]
    return []


def check_default_web_ports(ip, open_ports, banners):
    findings = []
    for entry in banners:
        text = (entry.get("banner") or "")
        if entry["port"] in (80, 8080, 8000, 8888) and "Server:" not in text and text:
            pass  # no-op placeholder, header check handled below
        if "X-Powered-By" in text:
            m = re.search(r"X-Powered-By:\s*(.+)", text)
            if m:
                findings.append(finding(
                    "HTTP-001", "X-Powered-By header discloses technology stack", "low",
                    f"Server discloses backend technology via header: {m.group(1).strip()}. "
                    f"This aids attacker reconnaissance. Consider removing this header.",
                    port=entry["port"], evidence=m.group(1).strip(),
                ))
    return findings


def check_tls_config(ip, open_ports, banners, timeout=4.0):
    """Checks for expired certs and weak TLS versions on HTTPS-like ports."""
    findings = []
    tls_ports = [p for p in open_ports if p in (443, 8443, 993, 995, 465, 636)]
    for port in tls_ports:
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with socket.create_connection((ip, port), timeout=timeout) as sock:
                with ctx.wrap_socket(sock, server_hostname=ip) as tls_sock:
                    cert = tls_sock.getpeercert()
                    tls_version = tls_sock.version()

                    if tls_version in ("TLSv1", "TLSv1.1", "SSLv3", "SSLv2"):
                        findings.append(finding(
                            "TLS-001", f"Weak TLS version negotiated ({tls_version})", "high",
                            f"Port {port} negotiated {tls_version}, which has known "
                            f"cryptographic weaknesses. Disable protocols below TLS 1.2.",
                            port=port, evidence=tls_version,
                        ))

                    if cert and "notAfter" in cert:
                        try:
                            expiry = datetime.datetime.strptime(
                                cert["notAfter"], "%b %d %H:%M:%S %Y %Z"
                            )
                            if expiry < datetime.datetime.utcnow():
                                findings.append(finding(
                                    "TLS-002", "TLS certificate expired", "medium",
                                    f"Certificate on port {port} expired on {expiry.isoformat()}. "
                                    f"Clients may reject connections or show warnings.",
                                    port=port, evidence=cert["notAfter"],
                                ))
                        except ValueError:
                            pass
        except ssl.SSLError as e:
            msg = str(e)
            if "wrong version number" in msg.lower():
                continue  # not actually TLS on this port
        except (socket.timeout, OSError, ConnectionRefusedError):
            continue
    return findings


# --- Registry ---------------------------------------------------------------

ALL_CHECKS = [
    check_telnet_open,
    check_ftp_anonymous,
    check_unencrypted_services,
    check_smb_exposed,
    check_rdp_exposed,
    check_database_exposed,
    check_vnc_exposed,
    check_default_web_ports,
    check_tls_config,
]


def run_misconfig_checks(ip, open_ports, banners, deep=False):
    """
    Run all registered misconfiguration checks against a host.
    Some checks (ftp anonymous login, tls handshake) do extra network I/O
    and are skipped unless deep=True to keep default scans fast.
    """
    fast_checks = [
        check_telnet_open, check_unencrypted_services, check_smb_exposed,
        check_rdp_exposed, check_database_exposed, check_vnc_exposed,
        check_default_web_ports,
    ]
    deep_checks = [check_ftp_anonymous, check_tls_config]

    checks = fast_checks + deep_checks if deep else fast_checks

    all_findings = []
    for check in checks:
        try:
            all_findings.extend(check(ip, open_ports, banners))
        except Exception:
            continue

    all_findings.sort(key=lambda f: SEVERITY_ORDER.get(f["severity"], 0), reverse=True)
    return all_findings
