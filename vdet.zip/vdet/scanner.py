"""
scanner.py - TCP connect port scanning engine.

Uses a thread pool for concurrency (no raw sockets / root required,
works cross-platform including Termux on Android).
"""

import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

# Timing templates, roughly mirroring nmap's -T0..-T5 philosophy.
# Each maps to (timeout_seconds, max_workers)
TIMING_TEMPLATES = {
    0: (5.0, 1),     # paranoid
    1: (3.0, 5),     # sneaky
    2: (2.0, 20),    # polite
    3: (1.0, 50),    # normal (default)
    4: (0.5, 150),   # aggressive
    5: (0.3, 300),   # insane
}


def scan_port(ip, port, timeout=1.0):
    """Attempt a TCP connect to ip:port. Returns True if open."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            result = sock.connect_ex((ip, port))
            return result == 0
    except (socket.timeout, OSError):
        return False


def scan_host(ip, ports, timing=3, progress_cb=None):
    """
    Scan a list of ports on a single host.
    Returns a sorted list of open port integers.

    progress_cb(done, total) is called after each port completes, if given.
    """
    timeout, max_workers = TIMING_TEMPLATES.get(timing, TIMING_TEMPLATES[3])
    open_ports = []
    total = len(ports)
    done = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(scan_port, ip, p, timeout): p for p in ports}
        for future in as_completed(futures):
            port = futures[future]
            done += 1
            if progress_cb:
                progress_cb(done, total)
            try:
                if future.result():
                    open_ports.append(port)
            except Exception:
                pass

    return sorted(open_ports)


def is_host_alive(ip, timeout=1.0):
    """
    Lightweight liveness check used before a full scan on subnet/range scans.
    Tries a TCP connect to a couple of very common ports since raw ICMP
    ping usually requires root. Falls back to 'assume alive' if both fail
    silently (caller can still just port-scan and get all-closed).
    """
    common_check_ports = [80, 443, 22, 445, 3389]
    for port in common_check_ports:
        if scan_port(ip, port, timeout=timeout):
            return True
    return None  # Unknown - caller decides whether to scan anyway
