"""
s_vdet - Network & Host Vulnerability Detector
Author: sithu-afk

A CLI tool for scanning network hosts, fingerprinting services/OS,
and matching detected software/OS versions against known CVEs.

LEGAL NOTICE: Only use against systems you own or have explicit
written authorization to test. Unauthorized scanning may be illegal
in your jurisdiction.
"""

__version__ = "0.1.0"
__author__ = "sithu-afk"
__app_name__ = "s_vdet"
