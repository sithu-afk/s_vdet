"""
cli.py - s_vdet command-line interface entry point (`vdet` command).

Usage examples:
    vdet 192.168.1.10
    vdet 192.168.1.0/24 --deep -oJ report.json
    vdet 10.0.0.5 --top-ports 100 -v -T4
    vdet 10.0.0.5 -p 445,3389,135 --deep --severity high
    vdet -iL targets.txt -o results.txt
    vdet 10.0.0.5 --os-detect --cve-scan
    vdet --update-cve-db --cve-target "windows_server_2012_r2"
"""

import argparse
import sys
import time

from . import __version__
from . import targets as targets_mod
from . import scanner
from . import banner as banner_mod
from . import fingerprint as fp_mod
from . import rules
from . import cve as cve_mod
from . import report
from . import consent
from .data.top_ports import get_top_ports, parse_port_spec


def build_parser():
    parser = argparse.ArgumentParser(
        prog="vdet",
        description="s_vdet - Network & Host Vulnerability Detector",
        epilog="Only scan systems you own or have explicit written authorization to test.",
    )
    parser.add_argument("target", nargs="?", help="Target: IP, CIDR, range, or hostname")
    parser.add_argument("-iL", metavar="FILE", dest="target_file",
                         help="Read targets from a file, one per line")

    port_group = parser.add_argument_group("Port options")
    port_group.add_argument("-p", "--ports", metavar="RANGE",
                             help="Ports to scan, e.g. 1-1000 or 22,80,443 (default: top 100)")
    port_group.add_argument("--top-ports", type=int, metavar="N",
                             help="Scan only the top N most common ports")

    scan_group = parser.add_argument_group("Scan behavior")
    scan_group.add_argument("-sV", action="store_true", dest="service_version",
                             help="Enable service/banner version detection")
    scan_group.add_argument("--deep", action="store_true",
                             help="Run full checks: banner grab, OS detect, CVE scan, TLS/FTP checks")
    scan_group.add_argument("-T", type=int, choices=range(0, 6), default=3, metavar="0-5",
                             help="Timing template: 0=paranoid .. 5=insane (default 3)")
    scan_group.add_argument("--os-detect", action="store_true",
                             help="Run OS fingerprinting (implied by --deep)")
    scan_group.add_argument("--cve-scan", action="store_true",
                             help="Match fingerprint against CVE database (implies --os-detect)")
    scan_group.add_argument("--cve-source", choices=["auto", "local", "nvd", "seed"], default="auto",
                             help="CVE data source (default: auto = local cache + seed DB)")
    scan_group.add_argument("--min-cvss", type=float, default=0.0, metavar="SCORE",
                             help="Only report CVEs with CVSS >= SCORE")

    cvedb_group = parser.add_argument_group("CVE database management")
    cvedb_group.add_argument("--update-cve-db", action="store_true",
                              help="Refresh local CVE cache from the NVD API and exit")
    cvedb_group.add_argument("--cve-target", metavar="CPE_OR_KEYWORD", action="append",
                              help="CPE name or keyword to fetch when using --update-cve-db "
                                   "(repeatable)")
    cvedb_group.add_argument("--nvd-api-key", metavar="KEY", help="NVD API key for higher rate limits")

    output_group = parser.add_argument_group("Output")
    output_group.add_argument("-o", "--output", metavar="FILE",
                               help="Write human-readable report to FILE")
    output_group.add_argument("-oJ", metavar="FILE", dest="output_json",
                               help="Write JSON report to FILE")
    output_group.add_argument("--severity", choices=["info", "low", "medium", "high", "critical"],
                               default="info", help="Minimum severity to display (default: info)")
    output_group.add_argument("-v", "--verbose", action="store_true", help="Verbose progress output")
    output_group.add_argument("--no-color", action="store_true", help="Disable colored output")

    consent_group = parser.add_argument_group("Authorization")
    consent_group.add_argument("--yes", "--no-consent-check", action="store_true", dest="assume_yes",
                                help="Skip the authorization confirmation prompt (for automation)")

    parser.add_argument("--version", action="version", version=f"s_vdet {__version__}")

    return parser


def resolve_target_specs(args):
    specs = []
    if args.target:
        specs.append(args.target)
    if args.target_file:
        specs.extend(targets_mod.load_targets_from_file(args.target_file))
    return specs


def resolve_ports(args):
    if args.ports:
        return parse_port_spec(args.ports)
    if args.top_ports:
        return get_top_ports(args.top_ports)
    return get_top_ports(100)


def scan_single_host(ip, ports, args):
    """Run the full scan pipeline against one host, return a result dict."""
    do_banners = args.service_version or args.deep or args.os_detect or args.cve_scan
    do_os_detect = args.os_detect or args.cve_scan or args.deep
    do_cve = args.cve_scan or args.deep
    do_misconfig_deep = args.deep

    if args.verbose:
        print(f"[*] Scanning {ip} ({len(ports)} ports, timing T{args.T})...", file=sys.stderr)

    def progress(done, total):
        if args.verbose and (done % 25 == 0 or done == total):
            print(f"    {ip}: {done}/{total} ports checked", file=sys.stderr)

    open_ports = scanner.scan_host(ip, ports, timing=args.T,
                                    progress_cb=progress if args.verbose else None)

    banners = []
    if open_ports and do_banners:
        if args.verbose:
            print(f"[*] Grabbing banners for {len(open_ports)} open ports on {ip}...", file=sys.stderr)
        banners = banner_mod.grab_banners(ip, open_ports)

    fingerprint = {"os_guesses": [], "software_guesses": [], "best_os": None, "best_os_confidence": None}
    if open_ports and do_os_detect:
        if args.verbose:
            print(f"[*] Fingerprinting OS for {ip}...", file=sys.stderr)
        fingerprint = fp_mod.fingerprint_host(ip, open_ports, banners)

    misconfig_findings = []
    if open_ports:
        misconfig_findings = rules.run_misconfig_checks(ip, open_ports, banners, deep=do_misconfig_deep)

    cve_matches = []
    if open_ports and do_cve:
        if args.verbose:
            print(f"[*] Matching CVEs for {ip}...", file=sys.stderr)
        cve_matches = cve_mod.match_cves(
            fingerprint["os_guesses"], fingerprint["software_guesses"],
            open_ports=open_ports, source=args.cve_source, api_key=args.nvd_api_key,
            min_cvss=args.min_cvss,
        )

    return report.build_host_result(ip, open_ports, banners, fingerprint, misconfig_findings, cve_matches)


def handle_update_cve_db(args):
    targets = args.cve_target or []
    if not targets:
        print("[!] --update-cve-db requires at least one --cve-target CPE_OR_KEYWORD", file=sys.stderr)
        return 1
    print(f"[*] Updating local CVE cache for {len(targets)} target(s)...")
    print("    (Respecting NVD rate limits - this may take a while)")
    try:
        count = cve_mod.update_local_db(targets, api_key=args.nvd_api_key)
        print(f"[+] Cache updated: {count} CVE records stored at {cve_mod.DEFAULT_DB_PATH}")
        return 0
    except Exception as e:
        print(f"[!] Update failed: {e}", file=sys.stderr)
        print("    Falling back to the built-in seed DB and live NVD queries during scans.", file=sys.stderr)
        return 1


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.update_cve_db:
        return handle_update_cve_db(args)

    specs = resolve_target_specs(args)
    if not specs:
        parser.print_help()
        return 1

    try:
        ips = targets_mod.resolve_targets(specs)
    except targets_mod.TargetParseError as e:
        print(f"[!] {e}", file=sys.stderr)
        return 1

    if not ips:
        print("[!] No valid targets resolved.", file=sys.stderr)
        return 1

    target_summary = ips[0] if len(ips) == 1 else f"{len(ips)} hosts ({ips[0]} ... {ips[-1]})"
    if not consent.confirm_authorization(target_summary, assume_yes=args.assume_yes):
        print("[!] Aborted - authorization not confirmed.")
        return 1

    ports = resolve_ports(args)

    results = []
    start = time.time()
    for i, ip in enumerate(ips, 1):
        if args.verbose and len(ips) > 1:
            print(f"\n[*] Host {i}/{len(ips)}: {ip}", file=sys.stderr)
        result = scan_single_host(ip, ports, args)
        results.append(result)
        if not args.output_json:
            report.print_host_report(result, min_severity=args.severity, use_color=not args.no_color)

    elapsed = time.time() - start
    if args.verbose:
        print(f"\n[*] Scan completed in {elapsed:.1f}s across {len(ips)} host(s).", file=sys.stderr)

    if args.output_json:
        report.write_json_report(results, args.output_json)
        print(f"\n[+] JSON report written to {args.output_json}")

    if args.output:
        report.write_text_report(results, args.output, min_severity=args.severity)
        print(f"[+] Text report written to {args.output}")

    return report.compute_exit_code(results)


if __name__ == "__main__":
    sys.exit(main())
