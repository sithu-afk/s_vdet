"""
top_ports.py - Common port lists used for default / --top-ports scans.

TOP_100 is ordered roughly by real-world prevalence (nmap-style top-ports
philosophy) so `--top-ports 20` gives you the 20 most useful ports first.
"""

TOP_100 = [
    21, 22, 23, 25, 53, 80, 81, 88, 110, 111, 113, 119, 123, 135, 137, 138,
    139, 143, 179, 199, 389, 427, 443, 444, 445, 465, 513, 514, 515, 543,
    544, 548, 554, 587, 631, 636, 646, 873, 990, 993, 995, 1025, 1026,
    1027, 1028, 1029, 1110, 1433, 1434, 1720, 1723, 1755, 1900, 2000,
    2001, 2049, 2121, 2717, 3000, 3128, 3306, 3389, 3986, 4899, 5000,
    5009, 5051, 5060, 5101, 5190, 5357, 5432, 5631, 5666, 5800, 5900,
    6000, 6001, 6379, 6646, 7070, 8000, 8008, 8009, 8080, 8081, 8443,
    8888, 9000, 9100, 9200, 9999, 10000, 27017, 32768, 49152, 49153,
    49154, 49155, 49156, 49157,
]

# Ports we know common service families live on - used for banner grab hints
SERVICE_HINTS = {
    21: "ftp",
    22: "ssh",
    23: "telnet",
    25: "smtp",
    53: "dns",
    80: "http",
    110: "pop3",
    111: "rpcbind",
    135: "msrpc",
    139: "netbios-ssn",
    143: "imap",
    389: "ldap",
    443: "https",
    445: "microsoft-ds",
    465: "smtps",
    587: "submission",
    631: "ipp",
    636: "ldaps",
    993: "imaps",
    995: "pop3s",
    1433: "mssql",
    1521: "oracle",
    2049: "nfs",
    3306: "mysql",
    3389: "rdp",
    5432: "postgresql",
    5900: "vnc",
    5985: "winrm",
    5986: "winrm-ssl",
    6379: "redis",
    8080: "http-proxy",
    8443: "https-alt",
    9200: "elasticsearch",
    27017: "mongodb",
}


def get_top_ports(n=100):
    return TOP_100[:n]


def parse_port_spec(spec):
    """
    Parse a port spec like '1-1000', '22,80,443', '1-100,443,8080-8090'
    into a sorted list of unique integer ports.
    """
    ports = set()
    for chunk in spec.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            start, end = chunk.split("-", 1)
            start, end = int(start), int(end)
            if start > end:
                start, end = end, start
            ports.update(range(start, end + 1))
        else:
            ports.add(int(chunk))
    return sorted(p for p in ports if 0 < p <= 65535)
