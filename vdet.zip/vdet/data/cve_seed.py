"""
cve_seed.py - Small curated offline seed database of well-known, high-impact
CVEs mapped to OS releases and common software. Used as an instant, no-network
fallback and to guarantee results for common lab/CTF targets (e.g. Windows
Server 2012 R2) even without live NVD access.

This is NOT a replacement for a full CVE feed - use `vdet --update-cve-db`
to build a complete local cache from the NVD API for comprehensive coverage.

Structure: keyed by a normalized "match key" (os name or software name),
each entry is a list of CVE records.
"""

SEED_CVE_DB = {
    "windows server 2012 r2": [
        {"id": "CVE-2020-0796", "cvss": 10.0, "severity": "CRITICAL",
         "summary": "SMBv3 compression buffer overflow enabling remote code execution ('SMBGhost').",
         "affects_port": [445]},
        {"id": "CVE-2019-0708", "cvss": 9.8, "severity": "CRITICAL",
         "summary": "Remote Desktop Services RCE via unauthenticated RDP connection ('BlueKeep').",
         "affects_port": [3389]},
        {"id": "CVE-2017-0144", "cvss": 8.1, "severity": "HIGH",
         "summary": "SMBv1 remote code execution via crafted packets ('EternalBlue').",
         "affects_port": [445]},
        {"id": "CVE-2017-0143", "cvss": 8.1, "severity": "HIGH",
         "summary": "SMBv1 remote code execution via crafted packets (EternalBlue family).",
         "affects_port": [445]},
        {"id": "CVE-2021-1675", "cvss": 8.8, "severity": "HIGH",
         "summary": "Windows Print Spooler remote code execution ('PrintNightmare').",
         "affects_port": []},
    ],
    "windows server 2012": [
        {"id": "CVE-2017-0144", "cvss": 8.1, "severity": "HIGH",
         "summary": "SMBv1 remote code execution via crafted packets ('EternalBlue').",
         "affects_port": [445]},
    ],
    "windows server 2008 r2": [
        {"id": "CVE-2017-0144", "cvss": 8.1, "severity": "HIGH",
         "summary": "SMBv1 remote code execution via crafted packets ('EternalBlue').",
         "affects_port": [445]},
        {"id": "CVE-2008-4250", "cvss": 10.0, "severity": "CRITICAL",
         "summary": "Server service RPC handling remote code execution ('Conficker'-related).",
         "affects_port": [445]},
    ],
    "openssh 7.4": [
        {"id": "CVE-2018-15473", "cvss": 5.3, "severity": "MEDIUM",
         "summary": "OpenSSH username enumeration via crafted authentication requests.",
         "affects_port": [22]},
    ],
    "openssh 6.6": [
        {"id": "CVE-2016-0777", "cvss": 5.5, "severity": "MEDIUM",
         "summary": "OpenSSH client roaming feature leaks private key material.",
         "affects_port": [22]},
    ],
    "iis 6.0": [
        {"id": "CVE-2017-7269", "cvss": 9.8, "severity": "CRITICAL",
         "summary": "IIS 6.0 WebDAV service buffer overflow remote code execution.",
         "affects_port": [80, 443]},
    ],
    "iis 7.5": [
        {"id": "CVE-2010-2730", "cvss": 9.3, "severity": "CRITICAL",
         "summary": "IIS FastCGI extension buffer overflow remote code execution.",
         "affects_port": [80]},
    ],
    "apache 2.4.49": [
        {"id": "CVE-2021-41773", "cvss": 7.5, "severity": "HIGH",
         "summary": "Path traversal and remote code execution via mod_cgi.",
         "affects_port": [80, 443]},
    ],
    "vsftpd 2.3.4": [
        {"id": "CVE-2011-2523", "cvss": 9.8, "severity": "CRITICAL",
         "summary": "vsftpd 2.3.4 contains a backdoor triggered by a ':)' smiley in username.",
         "affects_port": [21]},
    ],
    "proftpd 1.3.3": [
        {"id": "CVE-2010-4221", "cvss": 7.5, "severity": "HIGH",
         "summary": "ProFTPD 1.3.3 stack buffer overflow via crafted TELNET_IAC.",
         "affects_port": [21]},
    ],
    "smbv1": [
        {"id": "CVE-2017-0144", "cvss": 8.1, "severity": "HIGH",
         "summary": "SMBv1 remote code execution via crafted packets ('EternalBlue').",
         "affects_port": [445]},
        {"id": "CVE-2017-0143", "cvss": 8.1, "severity": "HIGH",
         "summary": "SMBv1 remote code execution via crafted packets (EternalBlue family).",
         "affects_port": [445]},
    ],
}


def lookup_seed_cves(match_keys):
    """
    match_keys: iterable of lowercase strings (os names / software strings)
    to check against the seed DB, either as exact or substring matches.
    Returns a de-duplicated list of CVE records.
    """
    results = []
    seen_ids = set()
    for key in match_keys:
        if not key:
            continue
        key_l = key.lower()
        for db_key, records in SEED_CVE_DB.items():
            if db_key in key_l or key_l in db_key:
                for rec in records:
                    if rec["id"] not in seen_ids:
                        seen_ids.add(rec["id"])
                        results.append(rec)
    return results
