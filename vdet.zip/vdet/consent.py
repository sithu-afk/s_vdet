"""
consent.py - Authorization gate shown before scanning.

Scanning systems you don't own or lack permission to test can be illegal.
This is a lightweight speed bump, not a legal safeguard - it's the tool's
job to make misuse deliberate, not the tool's job to enforce law.
"""

import sys

WARNING_TEXT = """
\033[93m⚠  LEGAL NOTICE\033[0m
   You are about to scan: {targets}
   Only scan systems you own or have explicit written authorization to test.
   Unauthorized scanning may violate computer misuse laws in your jurisdiction.
"""


def confirm_authorization(target_summary, assume_yes=False):
    """
    Prompt the user to confirm they're authorized to scan the given targets.
    Returns True if the scan should proceed.
    """
    if assume_yes:
        return True

    print(WARNING_TEXT.format(targets=target_summary))
    try:
        answer = input("   Continue? [y/N]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    return answer in ("y", "yes")
