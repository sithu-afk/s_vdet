import struct
from vdet import smb_fingerprint as sf


def test_negotiate_request_wellformed():
    req = sf._build_negotiate_request(message_id=0)
    assert req[:4] == b"\xfeSMB"
    assert len(req) > 64  # header + body + dialects


def test_ntlm_negotiate_message_signature():
    msg = sf._build_ntlm_negotiate_message()
    assert msg[:8] == b"NTLMSSP\x00"
    msg_type = struct.unpack_from("<I", msg, 8)[0]
    assert msg_type == 1


def test_spnego_wrapping_produces_gss_token():
    ntlm = sf._build_ntlm_negotiate_message()
    spnego = sf._build_spnego_neg_token_init(ntlm)
    assert spnego[0] == 0x60  # GSS-API InitialContextToken tag


def test_nbss_wrap_length_prefix_correct():
    payload = b"x" * 100
    wrapped = sf._nbss_wrap(payload)
    assert wrapped[0] == 0
    length = struct.unpack(">I", b"\x00" + wrapped[1:4])[0]
    assert length == 100
    assert wrapped[4:] == payload


def test_netbios_name_encoding_roundtrip():
    encoded = sf._encode_netbios_name("*SMBSERVER")
    assert len(encoded) == 34
    assert encoded[0] == 32
    assert encoded[-1] == 0
    nibble_chars = encoded[1:33].decode("ascii")
    decoded = bytes(
        ((ord(nibble_chars[i]) - 0x41) << 4) | (ord(nibble_chars[i + 1]) - 0x41)
        for i in range(0, 32, 2)
    )
    assert decoded == b"*SMBSERVER     \x00"


def test_ntlm_challenge_parsing_extracts_build():
    sig = b"NTLMSSP\x00"
    msgtype = struct.pack("<I", 2)
    target_name_fields = struct.pack("<HHI", 0, 0, 0)
    flags = struct.pack("<I", 0x02000000 | 0x00000001)
    server_challenge = b"\x11" * 8
    reserved = b"\x00" * 8
    target_info_fields = struct.pack("<HHI", 0, 0, 0)
    version = struct.pack("<BBH3sB", 10, 0, 19045, b"\x00\x00\x00", 15)

    challenge = (sig + msgtype + target_name_fields + flags +
                 server_challenge + reserved + target_info_fields + version)
    wrapped = b"\x00" * 20 + challenge + b"\x00" * 10

    parsed = sf._find_ntlm_challenge(wrapped)
    assert parsed is not None
    assert parsed["build"] == 19045
    assert parsed["major"] == 10


def test_ntlm_challenge_parsing_returns_none_without_version_flag():
    sig = b"NTLMSSP\x00"
    msgtype = struct.pack("<I", 2)
    target_name_fields = struct.pack("<HHI", 0, 0, 0)
    flags = struct.pack("<I", 0x00000001)  # NEGOTIATE_VERSION not set
    rest = b"\x00" * 24
    challenge = sig + msgtype + target_name_fields + flags + rest
    assert sf._find_ntlm_challenge(challenge) is None


def test_build_to_name_disambiguates_win10_vs_server():
    assert sf.BUILD_TO_NAME[19045] == "Windows 10 22H2"
    assert sf.BUILD_TO_NAME[20348] == "Windows Server 2022"
    assert sf.BUILD_TO_NAME[19045] != sf.BUILD_TO_NAME[20348]


def test_fingerprint_via_smb_returns_none_on_closed_port():
    # Port 1 is essentially guaranteed closed/unreachable in any sandboxed
    # test environment - this exercises the "never raises" contract.
    result = sf.fingerprint_via_smb("127.0.0.1", port=1, timeout=0.5)
    assert result is None
