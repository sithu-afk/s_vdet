from vdet import rules


def test_telnet_flagged():
    findings = rules.check_telnet_open("10.0.0.1", [23], [])
    assert len(findings) == 1
    assert findings[0]["rule_id"] == "TELNET-001"
    assert findings[0]["severity"] == "high"


def test_telnet_not_flagged_when_closed():
    assert rules.check_telnet_open("10.0.0.1", [22, 80], []) == []


def test_database_exposure_severity():
    findings = rules.check_database_exposed("10.0.0.1", [6379, 3306], [])
    ids = {f["rule_id"]: f for f in findings}
    assert ids["DB-005"]["severity"] == "critical"  # Redis
    assert ids["DB-001"]["severity"] == "high"       # MySQL


def test_smb_and_netbios_both_flagged():
    findings = rules.check_smb_exposed("10.0.0.1", [139, 445], [])
    rule_ids = {f["rule_id"] for f in findings}
    assert "SMB-001" in rule_ids
    assert "SMB-002" in rule_ids


def test_run_misconfig_checks_sorts_by_severity_desc():
    open_ports = [23, 445, 6379]  # telnet(high), smb(medium), redis(critical)
    findings = rules.run_misconfig_checks("10.0.0.1", open_ports, [], deep=False)
    severities = [f["severity"] for f in findings]
    order = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
    ranks = [order[s] for s in severities]
    assert ranks == sorted(ranks, reverse=True)


def test_no_findings_on_clean_host():
    findings = rules.run_misconfig_checks("10.0.0.1", [22], [], deep=False)
    assert findings == []
