import pytest
from vdet import targets


def test_single_ip():
    assert targets.parse_target_spec("192.168.1.10") == ["192.168.1.10"]


def test_cidr():
    ips = targets.parse_target_spec("192.168.1.0/29")
    assert len(ips) == 6
    assert "192.168.1.1" in ips
    assert "192.168.1.6" in ips


def test_short_range():
    ips = targets.parse_target_spec("192.168.1.10-15")
    assert ips == [
        "192.168.1.10", "192.168.1.11", "192.168.1.12",
        "192.168.1.13", "192.168.1.14", "192.168.1.15",
    ]


def test_full_range():
    ips = targets.parse_target_spec("192.168.1.1-192.168.1.3")
    assert ips == ["192.168.1.1", "192.168.1.2", "192.168.1.3"]


def test_invalid_range_end_before_start():
    with pytest.raises(targets.TargetParseError):
        targets.parse_target_spec("192.168.1.20-10")


def test_invalid_cidr():
    with pytest.raises(targets.TargetParseError):
        targets.parse_target_spec("192.168.1.0/99")


def test_resolve_targets_dedupes_and_preserves_order():
    result = targets.resolve_targets(["192.168.1.2", "192.168.1.1", "192.168.1.2"])
    assert result == ["192.168.1.2", "192.168.1.1"]


def test_resolve_hostname_failure_raises():
    with pytest.raises(targets.TargetParseError):
        targets.resolve_hostname("this-domain-should-not-exist-xyz123.invalid")
