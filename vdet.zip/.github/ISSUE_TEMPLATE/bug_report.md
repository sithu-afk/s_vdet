---
name: Bug report
about: Something isn't working as expected
title: "[BUG] "
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of what went wrong.

**Command run**
```
vdet ...
```

**Expected behavior**
What you expected to happen.

**Actual behavior**
What actually happened. Include full terminal output if possible
(redact any real IPs/hostnames you don't want public).

**Environment**
- OS running `vdet`: [e.g. Kali Linux, Termux/Android, Windows]
- Python version: `python3 --version`
- s_vdet version: `vdet --version`

**Target environment (if relevant to the bug)**
- Target OS: [e.g. Windows 10, Windows Server 2019]
- Confirm this was a system you own or were authorized to scan: [yes/no]

**Additional context**
Anything else that might help (e.g. firewall state, VM setup, network topology).
